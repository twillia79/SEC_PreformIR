using System.Configuration;
using System.Dynamic;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR.Client;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

namespace SEC.PreformTempControl.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TemperatureController : ControllerBase
    {

        #region Fields

        public IConfiguration Configuration { get; }
        private readonly ILogger<TemperatureController> _logger;

        #endregion

        #region Constructor

        public TemperatureController(ILogger<TemperatureController> logger, IConfiguration configuration)
        {
            _logger = logger;
            Configuration = configuration;
        }

        #endregion

        #region API METHODS

        [HttpGet(Name = "GetTemperature")]
        public decimal Get()
        {
            return 100;
        }

        [HttpPost(Name = "WriteTemperatureTag")]
        public async Task<bool> Post(float temperatureValue)
        {
            //update kepware tag
            await SetOPCFloat("E80_RSLogix_5000.Full_Bin_PU.Global.test_temp", temperatureValue);


            //send signalR off to client application to show change
            _SendClientNotification(temperatureValue);
            return true;
        }

        #endregion

        #region Talk to Kepware
        private async Task<OpcResultRoot> SetOPCFloat(string tagname, float value)
        {
            try
            {
                var urlString = "http://OH-OPC-01.sec.int:39320/iotgateway/write";
                using (var httpClient = new HttpClient())
                {
                    using (var request = new HttpRequestMessage(new HttpMethod("POST"), urlString))
                    {
                        var list = new List<object>();
                        dynamic root = new ExpandoObject();
                        root.id = tagname;
                        root.v = value;
                        list.Add(root);
                        var data = JsonConvert.SerializeObject(list);
                        request.Content = new StringContent(data);
                        request.Content.Headers.ContentType = MediaTypeHeaderValue.Parse("application/json");
                        var response = await httpClient.SendAsync(request);
                        if (response.IsSuccessStatusCode)
                        {
                            var ret = await response.Content.ReadAsAsync<OpcResultRoot>();
                            return ret;
                        }
                        else
                        {
                            return null;
                        }
                    }
                }
            }
            catch (Exception)
            {
                return null;
            }
        }
        #endregion

        #region Talk To Client
        private async Task _SendClientNotification(float temperature)
        {
            string url = "";

            url = Configuration.GetValue<string>("SignalRHubs:TemperatureHub");

            try
            {
                var connection = new HubConnectionBuilder().WithUrl(url, options =>
                    {
                        options.UseDefaultCredentials = true;
                    })
                    .Build();
                connection.Closed += async error =>
                {
                    await Task.Delay(new Random().Next(0, 5) * 1000);
                    await connection.StartAsync();
                };
                await connection.StartAsync();
                await connection.InvokeAsync("NotifyTempChange", temperature);
                // await connection.InvokeAsync("SendRefresh");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                _logger.LogInformation(ex.Message);
            }
        }
        #endregion

        #region Helper Classes  
        public class OpcResultRoot
        {
            public List<WriteResult> writeResults { get; set; }
        }

        public class WriteResult
        {
            public string id { get; set; }
            public bool s { get; set; }
            public string r { get; set; }
        }
        #endregion
    }
}