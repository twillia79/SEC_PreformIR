﻿const baseUrl = document.location.origin + document.location.pathname;
var res = baseUrl.substring(0, baseUrl.lastIndexOf('/'));


const connection = new signalR.HubConnectionBuilder()
    .withUrl(res + "/temperatureHub")
    .withAutomaticReconnect({
        nextRetryDelayInMilliseconds: retryContext => {
            if (retryContext.elapsedMilliseconds < 60000) {
                // If we've been reconnecting for less than 60 seconds so far,
                // wait between 0 and 10 seconds before the next reconnect attempt.
                return Math.random() * 10000;
            } else {
                // If we've been reconnecting for more than 60 seconds so far, stop reconnecting.
                return null;
            }
        }
    })
    .build();

async function start() {
    try {

        await connection.start();
        console.log("SignalR Connected.");
    } catch (err) {
        console.log(err);
        setTimeout(start, 5000);
    }
};

connection.on("NotifyTempChange", function (scan) {
    //change gauge on receive
    console.log(scan);

    $("#gauge").data("kendoRadialGauge").value(scan);
    $("#lblTemperature").text(scan);
});

connection.onclose(start);

// Start the connection.
start();









